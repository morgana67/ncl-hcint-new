<?php
echo "<title></title><style></style></head><body>" . $body . "</body></html>"
?>
