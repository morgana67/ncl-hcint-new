<?php

namespace App\Http\Controllers\Voyager\Core;

use TCG\Voyager\Http\Controllers\VoyagerCompassController as BaseVoyagerCompassController;

class VoyagerCompassController extends BaseVoyagerCompassController
{
    //
}
