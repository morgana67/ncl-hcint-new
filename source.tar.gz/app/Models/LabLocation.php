<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LabLocation extends Model
{
    protected $table = 'labs_locations';
    protected $guarded = ['id'];
}
