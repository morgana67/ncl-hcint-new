<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DiseaseType extends Model
{
    protected $table = 'disease_types';
    protected $guarded = ['id'];
}
