<?php

return [
    'meta_description' =>
        'Traditionally to order a lab test you have to make an appointment to see your doctor, wait in clinic waiting room with other sick patients, pay your copay, pay the doctors fee and get a surprise bill in the mail, why would you want to go through the stress? Browse our test menu and order on demand, on your terms, it’s the 21st century.'
    
];
?>

